#!/bin/bash

set -e

kubectl create ns istio-system
kubectl create ns spire
sleep 2
