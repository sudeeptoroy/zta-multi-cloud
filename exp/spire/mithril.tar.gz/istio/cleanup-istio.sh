#!/bin/bash

istioctl x uninstall --purge
kubectl delete namespaces istio-system
